package csc312;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collections;

import org.junit.Test;

import csc312.servlet.*;

public class TestProject2 {

	@Test
	public void testWordList() {
		Main m = new Main();
		Words w = new Words();
		String word[] = m.words;
		
		assertEquals(20, word.length);
	}
	
	@Test
	public void testWordFinderInputCheck() {
		WordFinder wf = new WordFinder();
		ArrayList<Integer> cl = new ArrayList<Integer>(); cl.add(44);
		
		int[] game = {1, 2, 3};
        char column[] = {'a', 'b', 'c', 'd', 'e'};
        int row[] = {1, 2, 3, 4, 5};
        
        assertTrue(wf.checkInput(cl, "44", "2", "a4", row, column));  // all of them right
        assertFalse(wf.checkInput(cl, "77", "2", "a4", row, column)); // contest id wrong 
        assertFalse(wf.checkInput(cl, "44", "4", "a4", row, column)); // game id wrong
        assertFalse(wf.checkInput(cl, "44", "2", "f4", row, column)); // column wrong
        assertFalse(wf.checkInput(cl, "44", "2", "e6", row, column)); // row wrong
        assertFalse(wf.checkInput(cl, "77", "4", "f6", row, column)); // all of them wrong
	}

	@Test
	public void testCorrectLetter() {
		WordFinder wf = new WordFinder();
		
		char[][] board1 = wf.board1;
		char[][] board2 = wf.board2;
		char[][] board3 = wf.board3;
		
        char column[] = {'a', 'b', 'c', 'd', 'e'};
		
		assertEquals('C', wf.getLetter(board1, "1", "a3", column));
		assertEquals('Z', wf.getLetter(board2, "2", "c2", column));
		assertEquals('a', wf.getLetter(board2, "3", "e1", column));
	}
	
	@Test
	public void testSolutionInput() {
		Solution s = new Solution();
		ArrayList<Integer> cl = new ArrayList<Integer>(); cl.add(44);
		
		assertTrue(s.checkSolutionInput(cl, "44", "1", "bee", "bee"));
		assertTrue(s.checkSolutionInput(cl, "44", "2", "yak", "yak"));
		assertTrue(s.checkSolutionInput(cl, "44", "3", "zoo", "zoo"));
		assertFalse(s.checkSolutionInput(cl, "44", "2", "bee", "yak"));
	}

	@Test
	public void testTopFiveScore() {
		TopScore ts = new TopScore();
		
		ArrayList<Integer> cl = new ArrayList<Integer>();
		ArrayList<Long> tlOld = new ArrayList<Long>();
		ArrayList<Long> tlNew = new ArrayList<Long>();
		
		cl.add(11); tlOld.add(4L);
		cl.add(22); tlOld.add(3L);
		cl.add(33); tlOld.add(1L);
		cl.add(44); tlOld.add(2L);
		cl.add(55); tlOld.add(6L);
		cl.add(66); tlOld.add(5L);
		
		for (int i = 0; i < tlOld.size(); i++) {
			tlNew.add(tlOld.get(i));
		}
		Collections.sort(tlNew);
		ArrayList<Integer> TopFive = ts.getTopFiveContest(cl, tlOld, tlNew, 5 );
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(33); al.add(44); al.add(22); al.add(11); al.add(66); 
		
		
		assertEquals(TopFive, al);
	}
	
	@Test
	public void testTimeOut() {
		Solution s = new Solution();
		WordFinder wf = new WordFinder();
		
		String gameIndex = "1";
		String hSearch = "", vSearch = "";
		String solution = "bee", result = "bee";
		char[][] board1 = wf.board1;
		long delay = 5000;
		boolean timeOK = true;
		
		long start = System.currentTimeMillis();
		
		try {
			Thread.sleep(delay);
			
	        if ( Integer.parseInt(gameIndex) == 1 ) {
	        		
	        		hSearch = s.getBoardAsStringHorizontally(board1);
	        		vSearch = s.getBoardAsStringVertically(board1);
	        		if (hSearch.contains(solution)) {
	        			result = solution;
	        		} 
	        		if (vSearch.contains(solution)) {
	        			result = solution;
	        		}
	        }
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		long end = System.currentTimeMillis();
		long totalTime = end - start;
		
		timeOK = (totalTime > delay) ? false : true;
		
		assertTrue(totalTime > delay);
		assertFalse(timeOK);
	}

}
